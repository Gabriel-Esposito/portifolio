# Em que cidade tu nasceu?

print('-=-='*15)
print('Ei, tu nasceu onde?')
resposta = str(input(': '))
print('-=-='*15)
r = resposta.strip()
r2 = r.capitalize()
r3 = r2.count('Santo')
if r3 < 1:
    print('\033[1;31m Cidade invalida!\033[m')
else:
    print(' Sua cidade "{}" \033[4;32m é valida!\033[m'.format(r2))
print('-=-='*15)
print('-_-fim do programa-_-')