# Hipotenusa

print('Hora de mais matemática basica')
c1 = float(input('Digite o primeiro valor dos catetos: '))
c2 = float(input('Digite o segundo valor dos catetos: '))
h = (c1 ** 2 + c2 ** 2) ** (1/2)
print('O valor da Hipotenusa é {:.2f} '.format(h))
print('-_-Fim do program-_-')