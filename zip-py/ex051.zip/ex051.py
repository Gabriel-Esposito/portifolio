# Progreção Aritimetrica

print('Fazendo progreção aritimetrica')
max = int(input('Digite o valor máximo: '))
razao = int(input('Digite qual é a razão: '))
for c in range(razao,max+1,razao):
    print(c)