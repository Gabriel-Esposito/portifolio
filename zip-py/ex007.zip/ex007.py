# Convertendo medidas
print('Olá! Hoje vamos converter medidas.')
medida = int(input(' Medida em metros: '))
km = medida / 1000
cm = medida * 100
print('Os metros {} convetidos para KM {} e convertidos para CM {}. '.format(medida,km,cm))
print('Obrigado por testar mais um programa :3 -FIM DO PROGRAMA-')