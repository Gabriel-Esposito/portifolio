# Contando de 1 a 10

from time import sleep

print('Fim de ano é sempre bom comemorar soltando fogosde artificil\nBora soltar?')
sleep(3)
for contagem in range(10,0,-1):
    sleep(1)
    print(contagem)
sleep(1)
print('*Fogos estourando!*')
print('==Fim==Do==Programa==')