# Tabuada 
print('Olá! Hoje vamos aprender a tabuada de um numero.')
n1 = int(input('Digite um numero: '))
s1 = n1 * 0
s2 = n1 * 1
s3 = n1 * 2
s4 = n1 * 3
s5 = n1 * 4
s6 = n1 * 5 
s7 = n1 * 6
s8 = n1 * 7
s9 = n1 * 8
s10 = n1 * 9
s11 = n1 * 10
print('{} x 0 = {}'. format(n1,s1))
print('{} x 1 = {}'. format(n1,s2))
print('{} x 2 = {}'. format(n1,s3))
print('{} x 3 = {}'. format(n1,s4))
print('{} x 4 = {}'. format(n1,s5))
print('{} x 5 = {}'. format(n1,s6))
print('{} x 6 = {}'. format(n1,s7))
print('{} x 7 = {}'. format(n1,s8))
print('{} x 8 = {}'. format(n1,s9))
print('{} x 9 = {}'. format(n1,s10))
print('{} x 10 = {}'. format(n1,s11))
print('A tabuada é facil! :D  --fim do programa--')