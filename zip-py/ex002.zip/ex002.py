# Fazendo soma de dois  numeros (Usamos + para adição/ Usamos - para diminuir)
# use o código: n1 = int(intput('digite numero'))
print('Olá! Esse é meu segundo programa!')
print('Vamos calcular alguns numeros? Bora!')
n1 = int(input('Digite um numero: '))
n2 = int(input('Digite outro numero: '))
soma1 = n1 + n2
print('A soma de {} mais {} é {}'.format(n1,n2,soma1)) 
soma2 = n1 - n2
print('A subitração dos numeros {} e {} é {}'.format(n1,n2,soma2))
print('Matematica basica, ----Fim!----')