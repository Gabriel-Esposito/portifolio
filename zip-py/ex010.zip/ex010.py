# Programa de cambio

print('Que tal viajar para outro pais? Vamos converter nosso dinheiro então!')
dinheiro = float(input('Dite quando você deseja converter: '))
dolar = dinheiro / 5.19
print('Com {} reais você vai conseguir comprar {} Dólaras!'.format(dinheiro,dolar))
print('-_-Fim do program-_-')