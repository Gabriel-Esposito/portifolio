# Ajuste salarial

print('Todos gostão de ganhar um almento de salario no trabalho!')
print('Bora calcular o aumento então!')
desconto = int(input('Digite o valor do desconto: '))
salario = float(input('Digite o valor do seu salario: '))
soma = (desconto * salario) / 100
total = salario + soma
print('Com o aumento de {}%, o salario de R${} passa a ser de R${} !'.format(desconto,salario,total))
print('-_-Fim do program-_-')