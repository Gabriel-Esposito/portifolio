# Sorteando lista

import random
print('Temos um trabalho para apresentar! quem vai primeiro?')
n1 = str(input('Digite o primeiro nome: '))
n2 = str(input('Digite o segundo nome: '))
n3 = str(input('Digite o terceiro nome: '))
n4 = str(input('Digite o quarto nome: '))
lista = [n1,n2,n3,n4]
sorteio = random.shuffle(lista)
print('A ordem da apresentasão vai ser : {} '.format(lista))
print('-_-Fim do program-_-')