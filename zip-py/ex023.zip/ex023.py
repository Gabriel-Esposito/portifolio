# Separando números

print('-=-=' *15)
print('Vamos ver se você realmente sabe matemática basica!')
numero = int(input('Digite um valor inteiro menor que 10 mil:\n'))
print('-=-=' *15)
u = numero // 1 % 10
d = numero // 10 % 10
c = numero // 100 % 10
m = numero // 1000 % 10
if numero > 1000:
    print('\033[1;31m Que número grande!!\033[m')
    print('Seu número é composto por {} milares, {} centenas, {} dezenas e {} unidades.'.format(m,c,d,u))
else:
    print('Seu número é composto por {} centenas, {} dezenas e {} unidades.'.format(c,d,u))
print('-=-=' *15)
print('-_-fim do programa-_-')