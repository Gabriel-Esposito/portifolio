# Seno, Cosseno, Tangente

import math
print('Mais uma de matemática basica! :D')
print('Seno, Cosseno e Tangente de um ângulo.')
ag = float(input('Digite o valor: '))
seno = math.sin(math.radians(ag))
coss = math.cos(math.radians(ag))
tang = math.tan(math.radians(ag))
print('O valor {} em:'.format(ag))
print('Seno {:.2f} !'.format(seno))
print('Cosseno {:.2f} !'.format(coss))
print('Tangente {:.2f} !'.format(tang))
print('-_-Fim do program-_-')