# Matematica media
# Usa float(input()) quando o numero tiver ','
# Use / para dividir algum numero
print('Olá! Realmente matematica é boa, mas não quando colocamos letras!')
print('Bora calcular medias de alunos')
nome = input('Qual o nome do aluno? ')
a1 = float(input('Digite a primeira nota: '))
a2 = float(input('Digite a sugunda nota: '))
soma1 = a1 + a2
soma2 = soma1 / 2
print('A media do aluno {} é {}!'.format(nome,soma2))
if soma2 >= 5:
    print('Parabéns {}! Você passou de ano!'.format(nome))
else:
    print('O aluno {} tirou {}, infelismente essa nota está abaixo de 5. Você está reprovado!'.format(nome,soma2))
print('---FIM DO PROGRAMA---')