# Sorteando em uma lista
# Usando as tags random.choice (aleatorio.escolha) para sortear um nome na lista

import random
print('Hora do sorteio! VAmos ver quem vai ganhar.')
n1 = str(input('Digite o primeiro nome: '))
n2 = str(input('Digite o segundo nome: '))
n3 = str(input('Digite o terceiro nome: '))
n4 = str(input('Digite o quarto nome: '))
lista = [n1,n2,n3,n4]
escolha = random.choice(lista)
print('O sortudo(a) foi {} ! Parabéns!'.format(escolha))
print('-_-Fim do program-_-')