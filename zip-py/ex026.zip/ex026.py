# Primeira e ultima letra

print('-=-='*15)
print('Seeu nome possui muitas letras A? Vamos ver!')
nome = str(input('Digite seu nome: ')).upper()
print('-=-='*15)
n = nome.count('A')
print('Seu nome possui {} letras A.'.format(n))
if n >= 1:
    print('O primeiro A apareceu na posição {}.'.format(nome.find('A')))
    print('O ultimo A apareceu na posição {}.'.format(nome.rfind('A')))
print('-=-='*15)
print('-_-fim do programa-_-')