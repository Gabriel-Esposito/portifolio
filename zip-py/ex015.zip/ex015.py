# Aluguel de carros

print('Vamos ver quanto ficou o carro que alugamos.')
dia = int(input('Por quantos dias o carro foi alugado? '))
km = int(input('Quantos KM o carro andou? '))
soma1 = dia * 60
soma2 = km * 0.15
total = soma1 + soma2
print('O valor por dia foi R${}'.format(soma1))
print('O valor por Km foi R$ {}'.format(soma2))
print('O valor total é R${}'.format(total))
print('-_-Fim do program-_-')