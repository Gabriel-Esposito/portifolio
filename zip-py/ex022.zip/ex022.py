# Analizando textos

print('-=-='*15)
print('Bom dia jogador! \nHoje vamos analizar frazes ok?\n---BORA PRO TRABALHO!---')
frase = str(input('Digite a sua frase:\n'))
print('-=-='*15)
print('Sua frase em Mausculo:\n{}'.format(frase.upper()))
print('Sua frase em minusculo:\n{}'.format(frase.lower()))
print('Sua frase tem {} espaços e {} letras.'.format(frase.count(' '),len(frase)-frase.count(' ')))
print('Obrigado pela a ajuda!')
print('-=-='*15)
print('-_-Fim do program-_-')