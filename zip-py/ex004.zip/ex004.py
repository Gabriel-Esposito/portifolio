# Mostrando o sucessor e antecessor do numero 
print('Olá! Vamos aprender mais matematica basica? Bora!')
n1 = int(input('Digite um numero: '))
a = n1 - 1
s = n1 + 1
print('O numero digitado foi {}, o antecessor dele é {} e o seu sucessor é {}.'.format(n1,a,s))
print('Matematica basica é facil para um professor ;) ---!Fim do Programa!---')