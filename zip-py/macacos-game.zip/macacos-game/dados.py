from time import sleep

class Macacos:
    def __init__(self,numeroMacacos=0,nome1='vazio',nome2='vazio',nome3='vazio',estomago1='vazio',estomago2='vazio',estomago3='vazio'):
      self.numeroMacacos = numeroMacacos
      self.nome1 = nome1
      self.nome2 = nome2
      self.nome3 = nome3
      self.estomago1 = estomago1
      self.estomago2 = estomago2
      self.estomago3 = estomago3
      '''
      Erro 01 = erro na digitação da criação de macacos.
      Erro 02 = erro no nome do macaco.
      Erro 03 = erro na escolha de 'sim' ou 'não' em 'CriarMacaco'.
      Erro 04 = erro na alimentação em 'Alimentar1'.
      Erro 05 = erro na escolha em 'Estomago1'.
      Erro 06 = erro na escolha de 'MenuAlimentacao1'.
      Erro 07 = erro na escolha de 'MenuAlimentacao2'.
      Erro 08 = erro na escolha de 'MenuAlimentacao3'.
      Erro 09 = erro na alimentação em 'Alimentar2'.
      Erro 10 = erro em ver macacos em 'Menu'.
      Erro 11 = erro na escolha em 'Estomago2'.
      Erro 12 = erro na escolha dos macacos em 'MenuAlimentacao2'.
      Erro 13 = erro na escolha dos macacos em 'MenuAlimentacao3'.
      Erro 14 = erro na alimentação em 'Alimentar3'.
      Erro 15 = erro na escolha em 'Estomago3'.
      '''

    def Menu(self):
        on = 0
        while on == 0:
            print('======'*12)
            print('===== Jogo dos macacos =====')
            res = input('1- Criar Macaco\n2- Ver Macacos\n3- Sair\n> ')
            if res == '1':
                self.CriarMacaco()
            elif res == '2':
                if self.numeroMacacos == 1:
                    self.MenuAlimentacao1()
                elif self.numeroMacacos == 2:
                    self.MenuAlimentacao2()
                elif self.numeroMacacos == 3:
                    self.MenuAlimentacao3()
                else:
                    print('==='*10)
                    print('[ERRO 10]')
            elif res == '3':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 01]')
                print('Valor digitato invalido!')

    def CriarMacaco(self):
        on = 0
        while on == 0:
            print('\n'*10)
            print('======'*12)
            print('O limite de criação  de macacos é 3!')
            res = input('Deseja criar macaco?\n[S/N] > ')
            if res == 's' or res == 'S':
                self.numeroMacacos += 1
                name = input('\nDigite o nome do novo Macaco.\n> ')
                if self.numeroMacacos == 1:
                    self.nome1 = name
                    sleep(1)
                elif self.numeroMacacos == 2:
                    self.nome2 = name
                    sleep(1)
                elif self.numeroMacacos == 3:
                    self.nome3 = name
                    sleep(1)
                elif self.numeroMacacos >= 4:
                    print('==='*10)
                    print('O Limite de Macacos ja foi atinjido!')
                    self.numeroMacacos -= 1
                    sleep(1.5)
                else:
                    print('==='*10)
                    print('[ERRO 02]')
                    print('Valor digitato invalido!')
                    sleep(2)
            elif res == 'n' or res == 'N':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 03]')
                print('Valor digitato invalido!')
                sleep(2)
    # Um Macaco         
    def MenuAlimentacao1(self):
        on = 0
        while on == 0:
            print('======'*12)
            print(f'1- {self.nome1}')
            res = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
            if res == '1':
                self.Alimentar1()
            elif res == '2':
                self.Estomago1()
            elif res == '3':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 06]')
                
    def Alimentar1(self):
        on = 0
        while on == 0:
            print('\n'*5)
            print('======'*12)
            print('===== Alimentar =====')
            print(f'1- {self.nome1}')
            res = input('\nFRUTAS\n1- Maçã\n2- Banana\n3- Uva\n4- Voltar\n> ')
            if res == '1':
                print(f'\n{self.nome1} Comeu uma Maçã')
                self.estomago1 = 'Maçã'
                sleep(1)
                on = 1
            elif res == '2':
                print(f'\n{self.nome1} Comeu uma Banana')
                self.estomago1 = 'Banana'
                sleep(1)
                on = 1
            elif res == '3':
                print(f'\n{self.nome1} Comeu uma Uva')
                self.estomago1 = 'Uva'
                sleep(1)
                on = 1
            elif res == '4':
                on = 1
                sleep(1)
            else:
                print('==='*10)
                print('[ERRO 04]')
                sleep(1.5)

    def Estomago1(self):
        on = 0
        while on == 0:
            print('======'*12)
            print('===== Estomago =====')
            print(f'\n1- {self.nome1}; barriga({self.estomago1})')
            res = input(f'\n1- Digerir [{self.estomago1}]\n2- Voltar\n> ')
            if res == '1' and self.estomago1 != 'vazio':
                print('====='*5)
                print('\nDigerindo comida...')
                sleep(1.5)
                self.estomago1 = 'vazio'
            elif res == '1' and self.estomago1 == 'vazio':
                print(f'\nO estomago do Macaco {self.nome1} está vazia!')
                sleep(1.5)
            elif res == '2':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 05]')
                self(1.5)
    # Dois Macacos
    def MenuAlimentacao2(self):
        on = 0
        while on == 0:
            print('======'*12)
            print(f'1- {self.nome1}\n2- {self.nome2}')
            escolha = input('\nEscolha um Macaco\n0- voltar\n> ')
            if escolha == '1':
                off = 0
                while off == 0:
                    print(f'Macaco escolhido: {self.nome1}')
                    res = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
                    if res == '1':
                        self.Alimentar1()
                    elif res == '2':
                        self.Estomago1()
                    elif res == '3':
                        off = 1
                    else:
                        print('==='*10)
                        print('[ERRO 07]')
                        sleep(1.5)
            elif escolha == '2':
                off = 0
                while off == 0:
                    print('======'*12)
                    print(f'\nMacaco escolhido: {self.nome2}')
                    res2 = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
                    if res2 == '1':
                        self.Alimentar2()
                    elif res2 == '2':
                        self.Estomago2()
                    elif res2 == '3':
                        off = 1
                    else:
                        print('==='*10)
                        print('[ERRO 07]')
                        sleep(1.5)
            elif escolha == '0':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 12]')

    def Alimentar2(self):
        on = 0
        while on == 0:
            print('\n'*5)
            print('======'*12)
            print('===== Alimentar =====')
            print(f'1- {self.nome2}')
            res = input('\nFRUTAS\n1- Maçã\n2- Banana\n3- Uva\n4- Voltar\n> ')
            if res == '1':
                print(f'\n{self.nome2} Comeu uma Maçã')
                self.estomago2 = 'Maçã'
                sleep(1)
                on = 1
            elif res == '2':
                print(f'\n{self.nome2} Comeu uma Banana')
                self.estomago2 = 'Banana'
                sleep(1)
                on = 1
            elif res == '3':
                print(f'\n{self.nome2} Comeu uma Uva')
                self.estomago2 = 'Uva'
                sleep(1)
                on = 1
            elif res == '4':
                on = 1
                sleep(1)
            else:
                print('==='*10)
                print('[ERRO 09]')
                sleep(1.5)
    
    def Estomago2(self):
        on = 0
        while on == 0:
            print('======'*12)
            print('===== Estomago =====')
            print(f'\n1- {self.nome2}; barriga({self.estomago2})')
            res = input(f'\n1- Digerir [{self.estomago2}]\n2- Voltar\n> ')
            if res == '1' and self.estomago2 != 'vazio':
                print('====='*5)
                print('\nDigerindo comida...')
                sleep(1.5)
                self.estomago2 = 'vazio'
            elif res == '1' and self.estomago2 == 'vazio':
                print(f'\nO estomago do Macaco {self.nome2} está vazia!')
                sleep(1.5)
            elif res == '2':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 11]')
                sleep(1.5)
    #Três Macacos
    def MenuAlimentacao3(self):
        on = 0
        while on == 0:
            print('======'*12)
            print(f'1- {self.nome1}\n2- {self.nome2}\n3- {self.nome3}')
            escolha = input('\nEscolha um Macaco\n0- voltar\n> ')
            if escolha == '1':
                off = 0
                while off == 0:
                    print(f'Macaco escolhido: {self.nome1}')
                    res = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
                    if res == '1':
                        self.Alimentar1()
                    elif res == '2':
                        self.Estomago1()
                    elif res == '3':
                        off = 1
                    else:
                        print('==='*10)
                        print('[ERRO 08]')
                        sleep(1.5)
            elif escolha == '2':
                off = 0
                while off == 0:
                    print('======'*12)
                    print(f'\nMacaco escolhido: {self.nome2}')
                    res2 = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
                    if res2 == '1':
                        self.Alimentar2()
                    elif res2 == '2':
                        self.Estomago2()
                    elif res2 == '3':
                        off = 1
                    else:
                        print('==='*10)
                        print('[ERRO 08]')
                        sleep(1.5)
            elif escolha == '3':
                off = 0
                while off == 0:
                    print('======'*12)
                    print(f'\nMacaco escolhido: {self.nome3}')
                    res2 = input('\n1- Alimentar\n2- Ver estomago \n3- Voltar\n> ')
                    if res2 == '1':
                        self.Alimentar3()
                    elif res2 == '2':
                        self.Estomago3()
                    elif res2 == '3':
                        off = 1
                    else:
                        print('==='*10)
                        print('[ERRO 08]')
                        sleep(1.5)
            elif escolha == '0':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 13]')

    def Alimentar3(self):
        on = 0
        while on == 0:
            print('\n'*5)
            print('======'*12)
            print('===== Alimentar =====')
            print(f'1- {self.nome3}')
            res = input('\nFRUTAS\n1- Maçã\n2- Banana\n3- Uva\n4- Voltar\n> ')
            if res == '1':
                print(f'\n{self.nome3} Comeu uma Maçã')
                self.estomago3 = 'Maçã'
                sleep(1)
                on = 1
            elif res == '2':
                print(f'\n{self.nome3} Comeu uma Banana')
                self.estomago3 = 'Banana'
                sleep(1)
                on = 1
            elif res == '3':
                print(f'\n{self.nome3} Comeu uma Uva')
                self.estomago3 = 'Uva'
                sleep(1)
                on = 1
            elif res == '4':
                on = 1
                sleep(1)
            else:
                print('==='*10)
                print('[ERRO 14]')
                sleep(1.5)

    def Estomago3(self):
        on = 0
        while on == 0:
            print('======'*12)
            print('===== Estomago =====')
            print(f'\n1- {self.nome3}; barriga({self.estomago3})')
            res = input(f'\n1- Digerir [{self.estomago3}]\n2- Voltar\n> ')
            if res == '1' and self.estomago3 != 'vazio':
                print('====='*5)
                print('\nDigerindo comida...')
                sleep(1.5)
                self.estomago3 = 'vazio'
            elif res == '1' and self.estomago3 == 'vazio':
                print(f'\nO estomago do Macaco {self.nome3} está vazia!')
                sleep(1.5)
            elif res == '2':
                on = 1
            else:
                print('==='*10)
                print('[ERRO 15]')
                sleep(1.5)