import dados
user = dados.Macacos()

user.Menu()