# Números par de 1 a 50

from time import sleep

print('Sabe quais são os número pares enter 1 a 50?\nVamos ver!')

for par in range(1,51):
    total = par % 2
    if total == 0:
        print(par)
    sleep(0.50)
print('==Fim==Do==Programa==')