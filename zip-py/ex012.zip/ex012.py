#Calculando descontos

print('Olá, hoje vamos calcular descontos :)')
desconto = int(input('Digite o valor do seu desconto: '))
valor = float(input('Digite o preço do produto: '))
soma = (valor * desconto) / 100
total = valor - soma
print('O valor do seu produto: {} reais com o desconto de {}% vai fica {} reais.'.format(valor,desconto,total))
print('-_-Fim do program-_-')