# Somar somente números pares entre 6 números

soma = 0
for numero in range(1,7):
    n = int(input('Digite um valor: '))
    par = n % 2
    if par == 0:
        soma = soma + n
print(soma)