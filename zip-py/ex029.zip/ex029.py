# Radar de velocidade 

print('Hora de dar multas para pessoas que gostão de passar do limite de velocidade permitido >:)')
velocidade = int(input('digite a velocidade do carro: '))
print('-=-=-' * 15)
limite = 80
if velocidade <= limite:
    print('Você está dentro do limite de velocidade permitido! ')
else:
    print('Você passou pelo radar acima da velocidade permitida!')
    s = velocidade - limite
    multa = s * 7
    print('Sua multa é de {} reais!'.format(multa))
print('-=-=-' * 15)
print('-_-Fim-_-do-_-Programa-_-')