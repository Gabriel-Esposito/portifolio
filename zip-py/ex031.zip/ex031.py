# Passagens de ônibus valor
# Como não podemos simplesmente fazr 1 x 0,5; fazemos 1 x 50 , resultado / 100; assim temos os centavos também 

print('-=-=-' * 20)
print('Ta querendo viajar mas está com medo de gastar muito?')
resposta = float(input('Sim(1) ou não(2)? '))
print('-=-=-' * 20)
if resposta == 1:
    print('Ok! irei te ajudar nessa :)')
    distancia = float(input('Quantos KM vai ser a viagem? '))
    if distancia <= 200:
        total1 = distancia * 50
        t1 = total1 / 100
        print('O valo total da sua viagem vai ser {} reais!'.format(t1))
    if distancia > 200:
        total2 = distancia * 40
        t2 = total2 / 100
        print('O valor total da sua viagem vai ser {} reais!'.format(t2))
if resposta == 2:
    print('Ok! Boa viagem.')
print('-=-=-' * 20)
print('------FIM DO PROGRAMA------')