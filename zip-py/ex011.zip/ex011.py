# Pintando paredes
# a cada 2m²

print('Hoje vamos pintar paredes, para isso precisamos saber quanto de tinta iremos gastar')
altura = float(input('Digite a altura da parede: '))
largura = float(input('Digite a largura da sua parede: '))
tamanho = altura * largura
tinta = tamanho / 2
print('O tamanho tatodal da parede é {}m², para isso vamos gastar {} litros de tinta para pintar toda a parede!'.format(tamanho,tinta))
print('-_-Fim do program-_-')