from time import sleep
import random
class Banco:
    def __init__(self,senha=0000,name='Adim',codigo='0000',Scodigo='0',saldo=0.0):
        self.nome = name
        self.senha = senha
        self.codigo = codigo
        self.Scodigo = Scodigo
        self.saldo = saldo

    def CriarConta(self):
        on = 0
        while on == 0:
            print('==='*15)
            print('==Criar Conta==')
            n = str(input('digite seu nome completo\n: '))
            s = int(input('Digite sua senha\n: '))
            sleep(1)
            print('Analizando dados...')
            sleep(3)
            if len(n) < 4:
                print('[ERRO]! Nome invalido!')
                sleep(1.5)
                print('\n'*7)
                on = 0
            else:
                self.nome = 'Adim'
                self.senha = 0000
                self.codigo = 0000
                self.Scodigo = 0
                self.saldo = 0.0
                self.codigo = random.randint(1000,9999)
                self.Scodigo= random.randint(0,9)
                print('Conta criada com sucesso!')
                print(f'seu código de acesso: \033[34;1m[{self.Scodigo}]-[{self.codigo}]\033[m')
                sleep(1.5)
                self.nome = n.title()
                self.senha = s
                self.codigo = str(self.Scodigo) + str(self.codigo)
                print('\n'*7)
                on = 1

    def EntarConta(self):
        on = 0
        while on == 0:
            print('==='*15)
            print('=====Login=====')
            nome = str(input('Nome completo:\n '))
            senha = int(input('Senha:\n '))
            cod = str(input('Insira seu código de acesso [1]-[1234]:\n '))
            sleep(1)
            print('Analizando dados...')
            sleep(1)
            print('\n'*7)
            if nome.title() != self.nome:
                print('\033[31;1m[ERRO]!\033[m Nome usuário errado ou incompleto!')
                on = 1
            elif senha != self.senha:
                print('\033[31;1m[ERRO]!\033[m Senha incoreta!')
                on = 1
            elif cod != self.codigo:
                print('\033[31;1m[ERRO]!\033[m Código invalido!')
                on = 1
            else:
                fim = 0
                while fim == 0:
                    print('==='*15)
                    if self.saldo == 0:
                        print(f'{self.nome}\nSaldo: R${self.saldo}\n1- Depositar\n2- Sacar\n3- Sair')
                    elif self.saldo < 0:
                        print(f'{self.nome}\nSaldo: \033[31;1mR${self.saldo}\033[m\n1- Depositar\n2- Sacar\n3- Sair')
                    elif self.saldo > 0:
                            print(f'{self.nome}\nSaldo: \033[36;1mR${self.saldo}\033[m\n1- Depositar\n2- Sacar\n3- Sair')

                    res = int(input('Digite sua ação: '))
                    if res == 1:
                        print('==='*15)
                        D = float(input('Valor a ser depositado:\n '))
                        self.saldo = self.saldo + D
                        print('\n'*4)
                    elif res == 2:
                        print('==='*15)
                        S = float(input('Valor a ser sacado: '))
                        self.saldo = self.saldo - S
                        print('\n'*4)
                    elif res == 3:
                        print('\n'*7)
                        fim = 1
                    else:
                        print('\033[31;4mValor digitado Invalido!\033[m')

                on = 1
    