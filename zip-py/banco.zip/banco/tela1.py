from dados import Banco
from time import sleep
user = Banco()
on = 0

while on == 0:
    print('==='*15)
    print('=====BANCO=====')
    print('1- Criar Conta\n2- Entar\n3- Sair')
    res = int(input('Digite sua ação: '))
    sleep(1)
    if res == 1:
        user.CriarConta()
        on = 0
    elif res == 2:
        user.EntarConta()
        on = 0
    elif res == 3:
        on = 1
    else:
        print('\033[31;4mValor digitado Invalido!\033[m')
        sleep(1.5)
        print('\n'*7)
