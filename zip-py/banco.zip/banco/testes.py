lista = []
lista =lista ,+ 1
lista =lista ,+ 2
print(lista)