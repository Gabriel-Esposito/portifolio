from time import sleep
from dados import Banco
user = Banco()

class Conta:
    def __init__(self,saldo=0.0):
        self.saldo = saldo

    def Saldo(self):
        print('==='*15)
        print(f'{user.nome}\nSaldo: R${self.saldo}\n1- Depositar\n2- Sacar\n3- Sair')
        if self.saldo < 0:
            self.saldo = f'\033[31;1m {self.saldo}\033[m'
        elif self.saldo > 0:
            self.saldo = f'\033[36;1m {self.saldo}\033[m'

    def Depositar(self):
        print('==='*15)
        D = float(input('Valor a ser depositado:\n '))
        self.saldo += D

    def Sacar(self):
        print('==='*15)
        S = float(input('Valor a ser depositado:\n '))
        self.saldo += S