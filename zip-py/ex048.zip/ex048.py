# Números impares entre 1 a 500 e multiplos de 3

from time import sleep

for numero in range(1,500):
    multiplo = numero % 3
    if multiplo == 0:
        impar = numero % 2
        if impar == 1:
            sleep(0.50)
            print(numero)
print('==Fim==do==Programa==')
