# matematica
# use * para multiplicar um numero
# use ** para elevar um numero (POTENCIA)
#use variavel ** (1/2) para saber a raiz quadrada de um numero
print('Olá Mundo! hoje vamos avancar um pouco na matematica basica :D')
n1 = int(input('Digite um numero: '))
soma1 = n1 * 2
soma2 = n1 * 3
soma3 = n1 ** (1/2)
print('O dobro do número {} é {}.'.format(n1,soma1))
print('O triplo do número {} é {}.'.format(n1,soma2))
print('A raiz quadrada do número {} é {}.'.format(n1,soma3))
print('O que achou do programa? :3 ---!FIM DO PROGRAMA!---')