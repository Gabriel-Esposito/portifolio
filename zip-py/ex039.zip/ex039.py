# Exercito
print('\033[1;33m-=-=-\033[m'*20)
print('Vamos ver se ja está na hora de se alistar?')
nome = str(input('Digite seu nome: '))
data = int(input('digite seu ano de nascemento: '))
print('\033[1;33m-=-=-\033[m'*20)
idade = 2022 - data
if idade == 18:
    print('{}, você pode se alistar esse ano!'.format(nome))
elif idade > 18:
    total = idade - 18
    print('{}, já faz {} anos que \033[4;31m você podia ter se alistado!\033[m'.format(nome,total))
else:
    print('{}, você ainda não tem idade para se alistar!'.format(nome))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')