from time import sleep

class Racas():
    def __init__(self,atk=0,hp=0,armadura=0,defesaT=0,espada=0,escudo=0,nivel=0,xp=0):
        self.atk = atk
        self.hp = hp
        self.armadura = armadura
        self.defesaT = defesaT
        self.espada = espada
        self.escudo = escudo
        self.nivel = nivel
        self.xp = xp

    def Guereiro(self):
        self.atk = 15
        self.hp = 100
        self.armadura = 10
        self.defesaT = 10
        self.espada = 0
        self.escudo = 0
        self.nivel = 1
        self.xp = 0