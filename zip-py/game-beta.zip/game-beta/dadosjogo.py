from time import sleep
from random import randint

class Jogador:
    def __init__(self,name='adim',senha='1234',raca='adim',atk=40,hp=50,armadura=0,defesaT=50,espada=0,escudo=0,nivel=4,xp=0,moedas=400,up=100,Iatk=0,Ihp=0,Inivel=0,Iarmadura=0,Iespada=0,Iescudo=0,Ixp=0,Imoedas=0,Iname='inimigo',Iraca='inimigo',IdefesaT=0,derrota=0,Pcura=3,Lhp=100,lihp=0):
        self.name = name
        self.senha = senha
        self.raca = raca
        self.atk = atk
        self.hp = hp
        self.armadura = armadura
        self.defesaT = defesaT
        self.espada = espada
        self.escudo = escudo
        self.nivel = nivel
        self.xp = xp
        self.moedas = moedas 
        self.up = up
        self.Pcura = Pcura
        self.Lhp = Lhp
        #inimigo
        self.Iatk = Iatk
        self.Ihp = Ihp
        self.Inivel = Inivel
        self.Iarmadura = Iarmadura
        self.Iespada = Iespada
        self.Iescudo = Iescudo
        self.Ixp = Ixp
        self.Imoedas = Imoedas
        self.Iname = Iname
        self.Iraca = Iraca
        self.IdefesaT = IdefesaT
        self.lihp = lihp
        self.derrota = derrota

    def Novo(self):
        print('==='*15)
        print('===Novo jogo===')
        print('Ao criar um novo jogo, o antigo é apagado!\nAo sair do jogo, seu progresso será perdido,\nIsso é só uma Beta.')
        n = input('\nQual seu nome? ')
        s = input('Sua senha: ')
        
        print('\nSelecione sua raça:\n1- Guerreiro\n0- Voltar')
        res = input('> ')
        if res == '1':
            self.raca = 'Guerreiro'            
            self.Guereiro()
            sleep(1)
            print('\nCriando conta...')
            self.name = n.title()
            self.senha = s
            self.derrota = 0
            sleep(1.5)
            print('\nCriada com sucesso!')
            sleep(1)
            print('\n'*7)
        elif res == '0':
            print('Saindo...')
            sleep(1)
            print('\n'*7)
        else:
            print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')
    
    def Salvo(self):
        on = 0
        while on == 0:
            print('==='*15)
            print('===Jogo salvo===')
            S = input('Digite sua senha ou [0 para sair]: ')
            if S == '0':
                on = 1
            elif S != self.senha:
                print('Senha invalida!')
            elif S == self.senha:
                self.Menu()
                on = 1

    def Menu(self):
        on = 0
        while on == 0:
            print('==='*15)
            self.Niveis()
            print(f'''
            Nome: {self.name}            | Armadura: {self.armadura}
            Class: {self.raca}           | Espada: {self.espada}
            HP: {self.hp} / {self.Lhp}   | Escudo: {self.escudo}
            Nivel: {self.nivel}          | Defesa: {self.defesaT}
            Força: {self.atk}            | Moedas: {self.moedas}
            Xp: {self.xp} / {self.up}    | Poção: {self.Pcura} (+35hp)''')
            print('\n1- Mercado\n2- Floresta\n0- Sair')
            res = input('Selecione sua ação: ')
            if res == '0':
                on = 1
                sleep(1)
            elif res == '1':
                sleep(1)
                self.Mercado()
            elif res == '2':
                self.Duelo()
                if self.derrota == 1:
                    on = 1
            else:
                print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')

    def Mercado(self):
        on = 0
        while on == 0:
            print('==='*15)
            print('1- Espada de ferro [200]\n2- Escudo de madeira [50]\n3- Armadura de couro [75]\n4- Poção de cura basica (+35) [50]\n0- Sair')
            res = input('\nSelecione sua ação: ')
            if res == '0':
                on = 1
                sleep(1)
            elif res == '1':# Espada de ferro ------------------------------------------------------------------
                v = 200
                if self.espada == 'Espada de ferro (+35)':
                    print('\nVocê ja possiu este item!')
                    sleep(1)
                elif v > self.moedas:
                    falta = v - self.moedas
                    print(f'\nVocê precisa de mais {falta} moedas para compar esse item!')
                    sleep(1)
                elif v <= self.moedas:
                    troco = self.moedas - v
                    self.moedas = troco
                    self.espada = 'Espada de ferro (+35)'
                    self.atk += 35
                    print(f'\nItem adiquirido com sucesso! seu troco é de {troco}')
                    sleep(1)
            elif res == '2':#Escudo de madeira ------------------------------------------------------------
                v = 50
                if self.escudo == 'Escudo de madeira (+20)':
                    print('\nVocê ja possiu este item!')
                    sleep(1)
                elif v > self.moedas:
                    falta = v - self.moedas
                    print(f'\nVocê precisa de mais {falta} moedas para compar esse item!')
                    sleep(1)
                elif v <= self.moedas:
                    troco = self.moedas - v
                    self.moedas = troco
                    self.escudo = 'Escudo de madeira (+20)'
                    self.defesaT += 20
                    print(f'\nItem adiquirido com sucesso! seu troco é de {troco}')
                    sleep(1)
            elif res == '3':# Armadura de couro ------------------------------------------------------
                v = 75
                if self.armadura == 'Armadura de couro (+20)':
                    print('\nVocê ja possiu este item!')
                    sleep(1)
                elif v > self.moedas:
                    falta = v - self.moedas
                    print(f'\nVocê precisa de mais {falta} moedas para compar esse item!')
                    sleep(1)
                elif v <= self.moedas:
                    troco = self.moedas - v
                    self.moedas = troco
                    self.armadura = 'Armadura de couro (+20)'
                    self.defesaT += 20
                    print(f'\nItem adiquirido com sucesso! seu troco é de {troco}')
                    sleep(1)
            elif res == '4':# Poção de cura basica ------------------------------------------------------------------
                v = 50
                if self.Pcura == 10:
                    print('\nVocê ja possiu o máximo deste item!')
                    sleep(1)
                elif v > self.moedas:
                    falta = v - self.moedas
                    print(f'\nVocê precisa de mais {falta} moedas para compar esse item!')
                    sleep(1)
                elif v <= self.moedas:
                    troco = self.moedas - v
                    self.moedas = troco
                    self.Pcura += 1
                    print(f'\nItem adiquirido com sucesso! seu troco é de {troco}')
                    sleep(1)
            else:
                print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')

    def Duelo(self):
        print('==='*15)
        print('Você encontrou um Goblin na floresta!')
        self.Goblins()
        on = 0
        while on == 0:
            if self.Ihp > 0 and self.hp > 0:
                print(f'''\n
                Nome: {self.Iname}            | Armadura: {self.Iarmadura}
                Class: {self.Iraca}           | Espada: {self.Iespada}
                HP: {self.Ihp} \ {self.lihp}      | Escudo: {self.Iescudo}
                Nivel: {self.Inivel}          | Defesa: {self.IdefesaT}
                Força: {self.Iatk}           ''')

                print(f'''\n
                Nome: {self.name}            | Armadura: {self.armadura}
                Class: {self.raca}           | Espada: {self.espada}
                HP: {self.hp} / {self.Lhp}      | Escudo: {self.escudo}
                Nivel: {self.nivel}          | Defesa: {self.defesaT}
                Força: {self.atk}            | Moedas: {self.moedas}
                Poção: {self.Pcura} (+35hp)''')
                res = input(f'1- Ataque basico ({self.atk})\n2- Usar poção\n0- Fugir\n: ')
                print('==='*15)
                if res == '0':
                    on = 1
                elif res == '1':
                    # Ataque jogador ------------------------------------------------------
                    if self.atk > self.IdefesaT and self.hp > 0:
                        j = (self.atk - self.IdefesaT)
                        self.Ihp -= j
                        print(f'{self.name} Feriu {self.Iname}. (-{j}hp)')
                    elif self.atk < self.IdefesaT and self.hp > 0:
                        self.Ihp -= 1
                        j = 1
                        print(f'{self.name} Feriu {self.Iname}. (-{j}hp)')  
                    # Ataque Inimigo -------------------------------------------------------  
                    if self.Iatk > self.defesaT and self.Ihp > 0:
                        i = (self.Iatk - self.defesaT)
                        self.hp -= i
                        print(f'{self.Iname} Feriu {self.name}. (-{i}hp)')
                    elif self.Iatk < self.defesaT and self.Ihp > 0:
                        self.hp -= 1
                        i = 1
                        print(f'{self.Iname} Feriu {self.name}. (-{i}hp)')
                elif res == '2':
                    print('oi')
                    if self.hp < self.Lhp:
                        diferenca = (self.Lhp - self.hp)
                        self.Pcura -= 1 
                        if diferenca >= 35:
                            print(f'{self.name} Usou uma Poção de cura basica! HP: +35')
                            self.hp += 35
                        else:
                            self.hp += diferenca
                            print(f'{self.name} Usou uma Poção de cura basica! HP: +{diferenca}')
                    # Ataque Inimigo -------------------------------------------------------------------- 
                    if self.Iatk > self.defesaT and self.Ihp > 0:
                        i = (self.Iatk - self.defesaT)
                        self.hp -= i
                        print(f'{self.Iname} Feriu {self.name}. (-{i}hp)')
                    elif self.Iatk < self.defesaT and self.Ihp > 0:
                        self.hp -= 1
                        i = 1
                        print(f'{self.Iname} Feriu {self.name}. (-{i}hp)')
                    elif self.Pcura <= 0:
                        print('===Você não possui poções de cura!===')
                else:
                    print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')
            elif self.hp <= 0:
                print('\n\033[31;m===Você foi derotado!===\033[m')
                print(f'\nPara continuar a jogar e não perder seus itens\numa taxa de 400 moedas deve ser paga!\nMoedas: {self.moedas}')
                reviver = 400
                res = input('Continuar? \033[31;1m[s/n]\033[m')
                if res == 's' or res == 'S':
                    if reviver > self.moedas:
                        print('\nInfelismente você não possui moedas o suficiente para continuar!\n\033[31;1mSeu progresso será perdido por completo!\033[m')
                        self.DeletarConta()
                        on = 1
                    elif reviver <= self.moedas:
                        print('\nSeu personagens está sendo revivido...')
                        self.derrota = 0
                        self.moedas -= reviver
                        sleep(5)
                        print('inimigo fuguiu...')
                        sleep(3)
                        print('===Revivido com secesso!===')
                        sleep(1)
                        on = 1
                elif res == 'n' or res == 'N':
                    self.DeletarConta()
                    on = 1
                else:
                    print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')
            elif self.Ihp <= 0 and self.hp > 0:
                print(f'\n{self.name} derotou {self.Iname}!\n===Drop===\nMoedas: {self.Imoedas}\nXp: {self.Ixp}')
                self.moedas += self.Imoedas
                self.xp += self.Ixp
                on = 1
            else:
                print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')
            




                
    def DeletarConta(self):
        print('\033[31;1mDeletando conta...\033[m')
        sleep(3)
        self.derrota = 1
        self.name = 'adim'
        self.senha = '1234'
        self.raca = 'adim'
        self.atk = 0
        self.hp = 0
        self.armadura = 0
        self.defesaT = 0
        self.espada = 0
        self.escudo = 0
        self.nivel = 0
        self.xp = 0
        self.moedas = 0
        self.up = 100
        self.Pcura = 3
        print('\033[31;1mApagando progresso...\033[m')
        sleep(3)
        print('\033[31;1mConta apagada!\033[m')
        sleep(1)

    def Niveis(self):
        while self.up <= self.xp:
            if self.xp >= self.up:
                self.nivel += 1
                self.xp -= self.up
                self.up += 100
                print('\033[36;1m===Você subiu de nivel!===\033[m')
                if self.nivel > 1 and self.nivel <= 10:
                    self.atk += 5
                    self.defesaT += 5
                    print('\033[36;1mDefesa: +5\nAtaque: +5\033[m')
                elif self.nivel > 10 and self.nivel <= 30:
                    self.atk += 10
                    self.defesaT += 10
                    self.hp += 10
                    print('\033[36;1mDefesa: +10\nAtaque: +10\nHp: +10\033[m')
                elif self.nivel > 30 and self.nivel <= 70:
                    self.atk += 20
                    self.defesaT += 20
                    self.hp += 30
                    print('\033[36;1mDefesa: +20\nAtaque: +20\nHp: +30\033[m')

    def Guereiro(self):
        self.atk = 15
        self.hp = 100
        self.armadura = 10
        self.defesaT = 10
        self.espada = 0
        self.escudo = 0
        self.nivel = 1
        self.xp = 0
        self.moedas = 0
        self.up = 100
        self.Pcura = 3

    def Goblins(self):
        if self.nivel >= 0 and self.nivel <= 4:
            self.Iatk = 15
            self.Ihp = 80
            self.Inivel = 2
            self.Iarmadura = 0
            self.Iespada = 'Espada de pedra (+5)'
            self.Iescudo = 0
            self.Ixp = 35
            self.Imoedas = 20
            self.Iname = 'Goblin'
            self.Iraca = 'Goblin'
            self.IdefesaT = 0
            self.lihp = 80
        elif self.nivel >= 5 and self.nivel <= 10:
            self.Iatk = 45
            self.Ihp = 140
            self.Inivel = 8
            self.Iarmadura = 'Armadura de couro (+20)'
            self.Iespada = 'Espada de ferro (+35)'
            self.Iescudo = 'Escudo de folha (+5)'
            self.Ixp = 80
            self.Imoedas = 70
            self.Iname = 'Goblin Guerreiro'
            self.Iraca = 'Goblin'
            self.IdefesaT = 25
            self.lihp = 140