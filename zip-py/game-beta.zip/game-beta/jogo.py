from time import sleep
import dadosjogo

user = dadosjogo.Jogador()

on = 0
while on == 0:
    print('==='*7)
    print('1- Novo jogo\n2- Jogo salvo\n3- Sair')
    res = input(': ')
    if res == '1':
        user.Novo()
    elif res == '2':
        user.Salvo()
    elif res == '3':
        on = 1
    else:
        print('\033[31;1m[ERRO]!\033[m Valor digitado não encontrado!')

