# Media dos alunos
print('\033[1;33m-=-=-\033[m'*20)
print('FIm de mais um bimestre! Vamos ver se você ficou de recuperação?')
nome = str(input('Digite o nome do aluno: '))
n1 = float(input('Digite a primeira nota: '))
n2 = float(input('Digite a segunda nota: '))
print('\033[1;33m-=-=-\033[m'*20)
soma = (n1 + n2) / 2
if soma < 5:
    print('O aluno {} foi \033[4;31m REPROVADO\033[m com media {}!'.format(nome,soma))
elif soma >= 5 and soma < 7:
    print('O aluno {} está em \033[4;32m RECUPERAÇÃO\033[m com media {}!'.format(nome,soma))
else:
    print('O aluno {} foi \033[4;36m APROVADO\033[m com media {}!'.format(nome,soma))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')