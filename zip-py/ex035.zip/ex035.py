# Criando triangulos
print('Olá jogador! :D')
print('Seja bem-vindo! Hoje vamos formar triangulos.')
print('Por que? porque sim!!!! >:D')
# inicio
r1 = float(input('Digite o primeiro valor: '))
r2 = float(input('Digite o segundo valor: '))
r3 = float(input('Digite o terceiro valor: '))
if r1 < r2 + r3 and r2 < r1 + r3 and r3 < r1 + r2:
    print('Os valores inseridos podem sim formar um triangulo! :D')
else:
    print('Infelismente os valores digitados não podem formar um triangulo! :c')
print('-_-Fim do program-_-')