# Verificando se o número é primo

n = int(input('Digite um valor: '))
impar = n % 2
if impar == 1:
    for numero in range(1,n +1):
        primo = n / numero 
        if primo == 1:
            print('O valor {} é primo!'.format(n))
        else:
            print('O valor {} não é primo!'.format)