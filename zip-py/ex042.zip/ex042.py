# Equilatero , Isósceles e Escaleno
print('\033[1;33m-=-=-\033[m'*20)
print('Vamos formar triangulos!')
m1 = float(input('Digite o primeiro valor: '))
m2 = float(input('Digite o segundo valor: '))
m3 = float(input('Digite o teerceiro valor: '))
print('\033[1;33m-=-=-\033[m'*20)
#Triangulo
if m1 < m2 + m3 and m2 < m1 + m3 and m3 < m1 + m2:
    print('As medidas {}, {}, {} \033[4;32m podem sim formar um triangulo!\033[m'.format(m1,m2,m3))
    if m1 == m2 == m3:
        print('Esse triangulo é \033[4;31m EQUILATERO!\033[m')
    elif m1 == m2 or m1 == m3 or m2 == m1 or m3 == m2:
        print('Esse triangulo é \033[4;31m ISÓSCELES!\033[m')
    else:
        print('Todos os lados são \033[4;31m diferentes!\033[m')
else:
    print('As medidas {}, {}, {} \033[1;31m não podem formar um triangulo!\033[m'.format(m1,m2,m3))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')