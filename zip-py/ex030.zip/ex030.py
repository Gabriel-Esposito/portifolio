# Programa que ve se o número é Par ou Impar
# todo número Par dividido por 2, resta 0
# todo número Impar dividido por 2, resta 1
print('hoje vamos ver se o número digitado é Impar ou Par: ')
n = int(input('digite unm número de sua preferencia: '))
print('-=-=-' * 10)
s = n % 2
if s == 0:
    print('O número digitado ({}) é Par!'.format(n))
if s == 1:
    print('O número digitado ({}) é impar'.format(n))
print('-=-=-' * 10)
print('<Fim do Programa!>')