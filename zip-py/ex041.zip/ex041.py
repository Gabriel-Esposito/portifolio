# Definindo categoria por idade 
print('\033[1;33m-=-=-\033[m'*20)
print('A qual categoria você pertence? ')
nome = str(input('Digite seu nome: '))
ano = int(input('Em que ano você nasceu?'))
print('\033[1;33m-=-=-\033[m'*20)
data = 2022 - ano
if data <= 9:
    print('\033[4;32m Sua categoria é Mirim!\033[m')
elif data >= 10 and data <= 14:
    print('\033[4;32m Sua categoria é Infantil!\033[m')
elif data >= 15 and data <= 19:
    print('\033[4;32m Sua categoria é Junior!\033[m')
elif data == 20:
    print('\033[4;32m Sua categoria é Sênior!\033[m')
else:
    print('Sua categoria é Master!')
print('Tenha bom jogos em sua categoria {}!'.format(nome))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRANMA--=\033[m')