# Vendendo casas
print('\033[1;33m-=-=-\033[m'*20)
print('Seja bem-vindo(a)!')
print('Vamos calcular se você tem direito a pegar o emprestimo.')
print('\033[1;33m-=-=-\033[m'*20)
#valores
valor = float(input('Qual o valor da casa? '))
salario = float(input('Seu salario: '))
anos = int(input('Quantos pretende pagar? '))
print('\033[1;33m-=-=-\033[m'*20)
#parcelas
mes = anos * 12
mensal = valor / mes
print('O valor da casa é de {} e a mensalidade é {:.2f}!'.format(valor,mensal))
#compra ou não
porcento = (salario * 30) / 100
if porcento < mensal:
    print('\033[1;31mInfelismente seu emprestimo foi recusado!\033[m')
    print('O valor da mensalidae é maior que 30% de seu salario, não será possivel pagar em {} anos!'.format(anos))
    print('30% de seu salario {:.2f}, mensalidade {:.2f}'.format(porcento,mensal))
    
else:
    print('\033[1;32mSeu emprestimo foi aprovado!\033[m')
    print('O valor por mês será {:.2f}!'.format(mensal))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=-FIM--DO--PROGRAMA-=\033[m')