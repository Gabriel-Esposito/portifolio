# Conversor de temperaturas

print('Será que esta calor ou frio? Bora descobrir :)')
c = float(input('Digite a temperatura em °C : '))
soma = (c * 1.8) + 32
k = c + 273
print('A temperatura atual em °F é {} e em K é {} .'.format(soma,k))
print('-_-Fim do program-_-')