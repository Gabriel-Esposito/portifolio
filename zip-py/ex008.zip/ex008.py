# comversor de metros 

print('Olá, Hoje vamos converter metros em KM, centimetros, milimetros')
metros = int(input('Digite a distancia em metros: '))
km = metros /1000
cm = metros * 100
mi = metros * 1000
print('A distancia em Km é ({})'.format(km))
print('A distancia em centimetros é ({})'.format(cm))
print('A distancia em milimetros é ({})'.format(mi))
print('-_-Fim do program-_-')