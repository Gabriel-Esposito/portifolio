# Quebrando números
# Para esse dever vamos importar a biblioteca (math) do python e a função trunc()

from math import trunc

print('Hoje vamos quebrar numeros não inteiros')
n = float(input('Digite seu valor: '))
print('O valor {} foi quebrado para {} '.format(n, trunc(n)))
print('-_-Fim do program-_-')