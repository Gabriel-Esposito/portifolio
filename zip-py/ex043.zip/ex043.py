# IMC (usando \n , podemos pular para a linha de baixo)
# baixo do peso 18.5
# peso ideal 18.5 a 25
# sobrepeso 25 até 30
# obesidade 30 até 40
# obesidade mórbida 40 para cima
print('\033[1;33m-=-=-\033[m'*20)
print('Manter uma alimentação saudável é sempre bom, também temos que controlar o pesso!\nVamos ver se você está no pesso ideal? Bora!!!')
print('\033[1;33m-=-=-\033[m'*20)
nome = str(input('Digite seu nome: '))
altura = float(input('Digite sua altura: '))
peso = float(input('Digite seu peso atual: '))
print('\033[1;33m-=-=-\033[m'*20)
a = altura * altura
p = peso / a
if p < 18.5:
    print('{}, você está \033[4;31m ABAIXO do peso!\033[m'.format(nome))
elif p >= 18.5 and p < 25:
    print('{}, você esta no peso \033[4;32m IDEAL!\033[m'.format(nome))
elif p >= 25 and p < 30:
    print('{}, você está no peso \033[4;36m SOBREPESO!\033[m'.format(nome))
elif p >= 30 and p <= 40:
    print('{}, você está no peso \033[4;31m OBESIDADE!\033[m'.format(nome))
else:
    print('{}, você está no peso \033[4;31m OBESIDADE MÓRBIDA!\033[m'.format(nome))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')