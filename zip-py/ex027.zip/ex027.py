# Primeiro e ultimo nome

print('-=-='*15)
nome = str(input('Qual seu nome jogador?\n: ')).strip()
print('-=-='*15)
n = nome.split()
print('Prazem em te conhecer!')
print('Seu primeiro nome é {}.'.format(n[0]))
print('Seu ultimo nome é {}.'.format(n[len(n) -1]))
print('-=-='*15)
print('-_-fim do programa-_-')