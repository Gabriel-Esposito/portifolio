#Nova tabuada

from time import sleep

n = int(input('Digite um valor: '))

for numero in range(0,11):
    r = n * numero
    print('{} x {} = {}'.format(n,numero,r))
    sleep(1)