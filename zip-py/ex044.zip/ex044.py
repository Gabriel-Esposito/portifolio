# Formas de pagamento (Para limpar o terminal = ctrl + L)
# À vista -10%
# À vista cartão -5% , 2 parcelas = preço normal
# 3 ou mais parcelas = +20%

print('\033[1;33m-=-=-\033[m'*20)
print('Bora Fazer umas comprinhas? :D')
produto = float(input('Digite o valor de seu produto:R$'))
print('\033[1;33m-=-=-\033[m'*20)
print('----Formas de pagamento: \nÀ vista 10% de desconto (1); \nÀ vista no cartão 5% de desconto(2); \nParcelar no cartão (3).')
pagamento = int(input('Digite a forma de pagamento: '))
print('\033[1;33m-=-=-\033[m'*20)
#dinheiro
if pagamento == 1:
    dinheiro = produto - ((produto * 10) / 100) 
    print('Valor do pagamento: R${}'.format(dinheiro))
#cartão
elif pagamento == 2:
    cartao = produto - ((produto * 5) / 100)
    print('Valor do pagamento: R${}'.format(cartao))
#parcelas
elif pagamento == 3:
    print('----Parcelas: \n2 parcelas : preço normal; \n 3 a 10 parcelas : 20% a mais. \n \033[4;31m limite de parcelas = 10\033[m')
    parcelas = int(input('Em quantas parcelas deseja pagar? '))
    print('\033[1;33m-=-=-\033[m'*20)
    if parcelas == 2:
        p2 = produto / 2
        print('o valor do pragamneto: R${}'.format(p2))
    elif parcelas >=3 and parcelas <=10:
        p3 = produto + ((produto * 20) / 100)
        total = p3 / parcelas
        print('Valor do pagamento: R${}'.format(total))
    else:
        print('\033[1;31m Valor de parcela invalido!\033[m')
else:
    print('\033[1;31m Forma de pagamento invalida!\033[m')
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')