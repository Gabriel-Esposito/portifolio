# cores
'''
Para colocar cores no Python use o código: \033[m ( para colocar um limite) \033[m
STYLE = 0 nada ; 1 Negrito ; 4 Sumblinhado ; 7 inverter cores
TEXT = 30 cinza ; 31 vermelho ; 32 verde ; 33 amarele ; 34 rosa ; 35 lilais ; 36 azul ; 37 branco
BACK = 40 cinza ; 41 vermelho ; 42 verde ; 43 amarelo ; 44 rosa ; 45 lilais ; 46 azul ; 47 branco
código = \033[STYLE;TEXT;BACKm
'''
#Exemplo 1

nome = 'Pedro'
print('\033[0;36;40m Olá \033[m  \033[4;32;47m {} \033[m !'.format(nome))

#Exemplo 2

nome = 'Pedro'
print('Olá {}{}{} !'.format('\033[4;32;47m',nome,'\033[m'))

#Exemplo 3

cor = {'verde':'\033[1;37;42m','fim':'\033[m'}
nome = 'Pedro'
print('{}Olá {} ! {}'.format(cor['verde'],nome,cor['fim']))