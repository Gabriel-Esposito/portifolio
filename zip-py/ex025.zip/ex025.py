# Proucurando dentro do nome

print('-=-='*15)
print('Queria saber seu nome')
nome = str(input(': '))
print('-=-='*15)
r = nome.strip()
r2 = r.title()
resposta = r2.count('Silva')
if resposta < 1:
    print('Seu sobrenome não possui Silva.')
else:
    print('Seu sobrenome tem Silva.')
print('-=-='*15)
print('-_-fim do programa-_-')