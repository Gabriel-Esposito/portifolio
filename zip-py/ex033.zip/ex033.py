# Qual o número maior?
# definimos um como o maior/menor para economizar um if
print('-=-=-' * 15)
print('Olà! :3')
print('Hoje vamos descobrir qual o maior e o menor valor dentre os três de sua escolha :3')
print('-=-=-' * 15)
n1 = int(input('Digite o primeiro valor: '))
n2 = int(input('Digite o segundo valor: '))
n3 = int(input('Digite o terceiro valor: '))
print('-=-=-' * 15)
maior = n1
if n2 > n1 and n2 > n3:
    maior = n2
if n3 > n1 and n3 > n2:
    maior = n3
print('O maior valor foi o {} !'.format(maior))
menor = n1
if n2 < n1 and n2 < n3:
    menor = n2
if n3 < n1 and n3 < n2:
    menor = n3
print('O menor valor foi o {} !'.format(menor))
print('-=-=-' * 15)
print('-=-=-Fim do Programa-=-=-')