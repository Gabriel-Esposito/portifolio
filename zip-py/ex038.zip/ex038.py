#Qual o maior?
print('\033[1;33m-=-=-\033[m'*20)
print('Vamos ver qual o maior valor!')
print('\033[1;33m-=-=-\033[m'*20)
n1 = int(input('Digite o primeiro valor: '))
n2 = int(input('Digite o segundo valor: '))
print('\033[1;33m-=-=-\033[m'*20)
if n1 > n2:
    print('O primeiro valor \033[1;31m{}\033[m é maior!'.format(n1))
elif n2 > n1:
    print('O segundo \033[1;31m{}\033[m é maior!'.format(n2))
else:
    print('OS valores {} e {} são iguais!'.format(n1,n2))
print('\033[1;33m-=-=-\033[m'*20)
print('\033[1;36m=--FIM--DO--PROGRAMA--=\033[m')